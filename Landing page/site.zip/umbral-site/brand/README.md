# LA CONTRA — Identidad visual v1.0

## Concepto rector

**Tensión impresa** combina la exactitud de una ficha táctica con la huella imperfecta de una baraja usada. La retícula representa la regla; los desplazamientos, rotaciones y texturas representan la capacidad de alterarla.

## Principios

1. **Directa:** la información de juego se entiende antes que la decoración.
2. **Tensa:** diagonales, escala y recortes producen presión visual.
3. **Física:** papel, semitono y raspado comunican consumo y memoria.

## Paleta

| Rol | HEX | Uso |
| --- | --- | --- |
| Tinta | `#111111` | Texto, bordes, contraste |
| Papel | `#F2EDDF` | Fondo y soporte |
| Azul Contra | `#3155FF` | Sistema, valor, acción principal |
| Coral Giro | `#FF5A47` | Cambio, inversión, conflicto |
| Amarillo Alerta | `#FFD84D` | Énfasis, puntuación, jugada válida |

Una pieza usa máximo tres colores activos además de Papel y Tinta.

## Tipografía

- **Archivo Black:** números, titulares y puntuación.
- **Newsreader:** explicación, estrategia y relato.
- **IBM Plex Mono:** estados de mesa, etiquetas y datos técnicos.

## Texturas

- **Papel:** soporte, 8–16% de opacidad.
- **Trama:** presión o foco, 12–24% de opacidad.
- **Raspado:** consumo o memoria, 8–18% de opacidad.

No usar las tres texturas con intensidad alta sobre el mismo plano.

## Archivos

- `Manual_Identidad_Visual_LA_CONTRA_v1.0.html`: fuente editable y lista para impresión.
- `../dist/assets/Manual_Identidad_Visual_LA_CONTRA_v1.0.pdf`: manual final descargable.
- `assets/logotipo-la-contra.svg`: firma horizontal principal.
- `assets/monograma-lc.svg`: identificador compacto para cartas y fichas.
